package com.codeqna;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodeQnAApplication {

    public static void main(String[] args) {
        SpringApplication.run(CodeQnAApplication.class, args);
    }

}
