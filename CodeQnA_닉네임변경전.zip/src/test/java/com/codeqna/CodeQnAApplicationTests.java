package com.codeqna;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeQnAApplicationTests {

    @Test
    void contextLoads() {
    }

}
