package com.codeqna.constant;

public enum UserRole {
    USER, ADMIN;
}
